/** Proposed in-process boundary. Controller JSONL remains 0.2.0. No renderer/simulator implementation. */
export type ClockMode = "human_realtime" | "human_practice" | "paused_code";
export interface ReplayHeader { replay_schema_version: "0.3.0"; engine_version: string; protocol_version: "0.2.0"; scenario_hash: string; clock_mode: ClockMode; replay_kind: "human" | "program"; }
export interface RendererAdapter<Snapshot, Event, Command> {
  mount(container: HTMLElement): void;
  applySnapshot(snapshot: Snapshot, checkpointSeq: number): void;
  applyEvents(events: readonly Event[]): void;
  setDisplayTime(atMs: number): void;
  setInteractionMode(mode: "human" | "readonly"): void;
  onCommand(listener: (command: Command) => void): () => void;
  dispose(): void;
}
