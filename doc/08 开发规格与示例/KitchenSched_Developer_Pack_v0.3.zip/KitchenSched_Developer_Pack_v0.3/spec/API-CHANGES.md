# v0.3 增量接口与迁移

本包的 spec/platform.openapi.yaml 是 v0.2 与 v0.3 增量合并后的设计规格，不是已经部署的服务。控制器 JSONL 协议保持 0.2.0。

## 新边界

- /model-connections：受保护的模型连接与只写凭据；创建本身不发模型请求，显式 probe 可能消耗供应商额度。
- /experiments：以固定 methodology 为入口，编排生成与旧版 evaluations；禁止用户直接指定隐藏 case 或覆写提示词。
- /collections：只整理已有结果，不发起计算；加入公开结果不扩大底层权限。
- /shares：创建和撤销白名单结果分享；链接 token 只在创建成功时返回。
- /public/methodologies：固定系统/任务提示词与工具说明、版本/哈希。仅返回已发布方法。
- /public/results：仅返回已发布 PublicResult；未公开资源统一 404。

GET 列表均使用 limit/cursor。需认证的读取限定本人或明确授权。每个写请求要求 Idempotency-Key；secret-bearing 请求记录服务端 HMAC 指纹，不把原始 key 写进幂等表。原始密钥只进入 secret store。分享创建的重试需要安全重取相同一次性响应，或者明确返回已创建的 share_id 并要求旋转链接；不得为了幂等永久明文保存 token。

## 秘密与端点

HTTPS URI Schema 仅验证形状，不替代 SSRF 出站检查。正式连接 snapshot 不携带 api_key；读取连接只返回 credential_present 与 credential_retention。single_experiment 的连接通过一个成功创建的 experiment 原子认领，终态或过期后清除秘密；不允许同时由两个实验消费。同一实验的固定重复次数可以使用该凭据。

## 兼容与实施阶段

原 /evaluations 仍为 organizer/internal 的冻结提交矩阵。新的 submitter 经 /experiments 请求服务端策略，不提高为 organizer。首版由 organizer 使用新增连接与实验接口；/collections、/shares 和 submitter 自助入口标为 later。接口路径完整声明不代表首版必须全部上线。

新增 owner_user_id 及外键前迁移旧数据到初始 owner，不允许无归属行。现有 run_id/submission_id/benchmark_id 与内容哈希保持不变。个人列表和分享应引用不可变结果，不引用不断变动的 latest。

## 发布阻断项

实际 pi commit、镜像 digest、模型适配映射、工具 schema、开发预算、上下文限制、日志保留和出站策略均需锁定并通过集成测试。harness/profile.draft.json 的 null 是明确阻断项，不应被运行器替换成隐式默认值。tools.contract.draft.json 不是 Pi 内建工具 Schema 的逐字复制；实现应采用发布版本中冻结的沙箱工具契约并重新计算哈希。
