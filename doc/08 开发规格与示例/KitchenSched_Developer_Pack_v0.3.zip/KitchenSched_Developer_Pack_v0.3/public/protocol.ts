// Generated structural types for protocol 0.2.0.
// Runtime validators and simulator enforce numeric and cross-field constraints.

export type Id = string;

export type UInt = number;

export type PositiveInt = number;

export type Hash = string;

export type ItemQty = {
  item_id: Id;
  quantity: PositiveInt;
};

export type LotQty = {
  lot_id: Id;
  quantity: PositiveInt;
};

export type Item = {
  id: Id;
  name: string;
  supply: "unlimited_raw" | "produced";
  orderable: boolean;
  price_minor: UInt;
};

export type StationDef = {
  id: Id;
  kind: string;
  name: string;
};

export type StationOption = {
  station_id: Id;
  duration_ms: PositiveInt;
  max_batches: number;
};

export type Recipe = {
  id: Id;
  name: string;
  inputs: Array<ItemQty>;
  outputs: Array<ItemQty>;
  station_options: Array<StationOption>;
};

export type Limits = {
  init_wall_ms: number;
  decision_wall_ms: number;
  total_cpu_ms: number;
  memory_mib: number;
  max_decisions: number;
  max_actions_per_decision: number;
  max_total_actions: number;
  min_wake_delay_ms: number;
  max_message_bytes: number;
  max_stderr_bytes: number;
  max_pids: number;
  max_writable_mib: number;
  max_orders_per_run: number;
};

export type Rules = {
  clock: "paused_code";
  settlement: "whole_order";
  batch_timing: "fixed_within_capacity";
  finish_at_deadline_counts: true;
  delivery_duration_ms: 0;
  cancellation: "unsupported";
};

export type PublicScenario = {
  protocol_version: "0.2.0";
  scenario_id: Id;
  scenario_version: string;
  difficulty: "easy" | "medium" | "complex";
  end_at_ms: PositiveInt;
  currency_unit: "credit_minor";
  currency_scale: 100;
  items: Array<Item>;
  recipes: Array<Recipe>;
  stations: Array<StationDef>;
  rules: Rules;
  limits: Limits;
};

export type Order = {
  id: Id;
  arrived_at_ms: UInt;
  items: Array<ItemQty>;
  value_minor: PositiveInt;
};

export type Lot = {
  id: Id;
  item_id: Id;
  quantity: PositiveInt;
  produced_at_ms: UInt;
  task_id: Id;
};

export type Task = {
  id: Id;
  recipe_id: Id;
  station_id: Id;
  batches: PositiveInt;
  started_at_ms: UInt;
  finish_at_ms: UInt;
};

export type StationState = {
  id: Id;
  task_id: (Id) | (null);
};

export type ActionResult = {
  action_id: Id;
  ok: boolean;
  code: "OK" | "UNKNOWN_RECIPE" | "UNKNOWN_STATION" | "INCOMPATIBLE_STATION" | "STATION_BUSY" | "INVALID_BATCH" | "UNKNOWN_LOT" | "DUPLICATE_LOT" | "INVALID_INPUT" | "INSUFFICIENT_INPUT" | "UNKNOWN_ORDER" | "INCOMPLETE_ORDER" | "ALREADY_DELIVERED" | "ACTION_ID_CONFLICT" | "DEADLINE_REACHED";
  entity_id: (Id) | (null);
  replayed: boolean;
};

export type WakeResult = {
  ok: boolean;
  code: "SCHEDULED" | "CANCELED" | "INVALID_WAKE_TIME";
  pending_wake_at_ms: (UInt) | (null);
};

export type Observation = {
  now_ms: UInt;
  state_version: UInt;
  final: boolean;
  orders: Array<Order>;
  inventory: Array<Lot>;
  running_tasks: Array<Task>;
  stations: Array<StationState>;
  revenue_minor: UInt;
  previous_results: Array<ActionResult>;
  previous_wake_result: (WakeResult) | (null);
  pending_wake_at_ms: (UInt) | (null);
};

export type StartAction = {
  type: "start";
  action_id: Id;
  recipe_id: Id;
  station_id: Id;
  batches: PositiveInt;
  input_lots: Array<LotQty>;
};

export type DeliverAction = {
  type: "deliver";
  action_id: Id;
  order_id: Id;
  output_lots: Array<LotQty>;
};

export type Action = (StartAction) | (DeliverAction);

export type Init = {
  type: "init";
  protocol_version: "0.2.0";
  request_id: Id;
  run_token: Id;
  policy_seed: number;
  config: PublicScenario;
};

export type Ready = {
  type: "ready";
  protocol_version: "0.2.0";
  request_id: Id;
};

export type Observe = {
  type: "observe";
  request_id: Id;
  observation: Observation;
};

export type Decision = {
  type: "decision";
  request_id: Id;
  observed_version: UInt;
  actions: Array<Action>;
  wake_at_ms: (UInt) | (null);
};

export type EndResult = {
  status: "completed" | "candidate_failed" | "infra_failed" | "canceled" | "disqualified";
  score_minor: (UInt) | (null);
  revenue_minor: UInt;
  delivered_orders: UInt;
  failure_code: (string) | (null);
  final_action_results: Array<ActionResult>;
  final_wake_result: (WakeResult) | (null);
};

export type End = {
  type: "end";
  result: EndResult;
};

export type HostMessage = Init | Observe | End;
export type ControllerMessage = Ready | Decision;
