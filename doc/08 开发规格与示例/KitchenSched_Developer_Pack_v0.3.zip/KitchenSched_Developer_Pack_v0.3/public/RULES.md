# KitchenSched 参赛公开规则

protocol_version 0.2.0 · 代码控制器

## 1. 任务

实现一个通过指定协议控制系统的程序。目标是在全局仿真截止前最大化合法完整交付订单的交易总额。可以不处理部分订单；未处理订单没有额外扣分。

你的程序在每局初始化时收到本局完整公开配置，包括物品、配方、设备、截止时刻与运行限制。运行期间只能通过协议读取已发生的状态并提交动作，不得联网、调用 LLM、访问宿主或其他运行数据。

## 2. 数值与配置

时间为整数毫秒，数量为正整数，金额为整数最小计价单位。配置以 public-scenario.schema.json 定义。可售物品拥有固定 price_minor；订单价值等于各品项单价乘数量之和。score_minor 是最终官方分，revenue_minor 是运行中的已记账收入。

unlimited_raw 原料由系统按配方供应，不作为库存批次，也不可直接销售。produced 物品通过加工产生批次。不存在采购、原料成本、保质期或仓储容量限制。

配方输入和输出以每批计，所选设备声明 duration_ms 和 max_batches。一次加工 batches 批，所有输入输出乘 batches；合法批量内耗时固定。每台设备同时最多执行一个任务，所有输出到加工结束时一次产生。

## 3. 通信

每条 UTF-8 JSON 消息一行，以 LF 结束，stdout 只输出协议消息并 flush，日志写 stderr。Host 先发送 init，程序回复 ready；随后每条 observe 必须回复一条 decision；收到 end 后无需回复并退出。

初始化不会改变世界。第一次 observe 在 t=0 发送，即使 orders 为空。后续 observe 由世界事件、主动唤醒或截止触发。程序计算时仿真暂停，但受真实资源限制。

消息必须符合 controller.schema.json，不能带未知字段、重复 JSON 键或不匹配的 request_id。decision 的 observed_version 必须等于对应观测的 state_version。

## 4. 观测

observe 包括 now_ms、state_version、final、orders、inventory、running_tasks、stations、revenue_minor、previous_results、previous_wake_result 和 pending_wake_at_ms。orders 是所有已到达且尚未交付订单；库存只包含正数量批次。

没有订单独立超时，订单保留到交付或全局截止。系统不提供未来订单，程序只能操作当前已存在的对象。所有合法静态配方和设备能力都在 init 中给出。

## 5. 动作

start 指定 action_id、recipe_id、station_id、batches、input_lots。生产不要求订单 ID。无限原料无需库存引用，其余输入批次按品项聚合后必须恰好满足配方；不能重复引用 lot_id，也不能多给、少给或混入其他品项。

deliver 指定 action_id、order_id、output_lots。必须一次满足整张订单全部品项数量，成功后立即消耗库存并计入订单金额。部分交付、替代物品和重复交付不产生收入。打包耗时仅由已声明配方表达，交付动作本身即时。

多个动作按数组顺序处理，每个动作单独原子成功或失败。后续动作能看到先前成功扣减的库存和设备占用，不能使用尚未完成的任务输出。actions 可以为空。

## 6. 唤醒

decision 必填 wake_at_ms。null 清除已有唤醒；未来整数替换已有唤醒，必须至少晚于 now_ms＋min_wake_delay_ms，且不晚于 end_at_ms。非法值只拒绝唤醒更新并保留旧值，不影响其他合法动作。

系统最多保留一个待触发唤醒。其他事件提前触发 observe 不会自行取消旧唤醒。同刻的多种世界事件合并为一次 observe。

## 7. 截止与得分

在 end_at_ms 恰好完成的加工先产出，随后程序收到 final=true 的最后一次 observe。该次仅允许 deliver，start 被拒绝，wake_at_ms 应为 null。响应处理后立即结束，不自动帮助分配或交付库存。

只有截止前及最终回调中实际成功的唯一完整交付才计收入。超时任务、剩余库存和未交付订单不计分。每张订单最多计一次。

## 8. 幂等与错误

action_id 在整局唯一。相同 ID 与相同内容再次发送返回首次结果，不再次执行；同 ID 不同内容返回 ACTION_ID_CONFLICT。首次失败结果也缓存，之后重新尝试需要新 ID。

ActionResult 含 action_id、ok、code、entity_id、replayed。常见业务错误包括 STATION_BUSY、INVALID_BATCH、UNKNOWN_LOT、DUPLICATE_LOT、INVALID_INPUT、INSUFFICIENT_INPUT、UNKNOWN_ORDER、INCOMPLETE_ORDER、ALREADY_DELIVERED、DEADLINE_REACHED。所有动作业务错误码列于 Schema；业务拒绝不结束本局。

结构错误、消息超限、不匹配请求、崩溃或资源超限导致 candidate_failed，官方分数为 0；基础设施故障由测试方按相同条件重跑。stderr 超限会截断。所有预算由本局 config.limits 指定。

## 9. 提交

ZIP 根目录包含 submission.json 和代码。manifest 声明 protocol_version、language、entrypoint 字符串数组。禁止绝对路径、目录穿越、符号链接和未允许依赖。模板 controller.py 只实现消息收发和空响应；需要自行实现控制逻辑。

开发与练习预算、运行时版本和依赖集合以发布清单为准。正式评测使用冻结的代码和依赖，不得在运行中改写提交或接受人工干预。
