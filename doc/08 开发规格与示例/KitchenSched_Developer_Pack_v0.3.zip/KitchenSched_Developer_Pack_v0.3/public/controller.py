#!/usr/bin/env python3
"""Protocol-only no-op template. Implement on_observe for the submission."""
from __future__ import annotations
import json
import sys
from typing import Any

MAX_MESSAGE_BYTES = 4_194_304

def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result

def on_initialize(config: dict[str, Any], policy_seed: int) -> None:
    """Read this run's configuration. This callback cannot change the world."""
    pass

def on_observe(observation: dict[str, Any]) -> tuple[list[dict[str, Any]], int | None]:
    """Return action objects and the next wake time, or None to cancel it."""
    return [], None

def send(message: dict[str, Any]) -> None:
    data = (json.dumps(message, ensure_ascii=True, separators=(",", ":")) + "\n").encode("utf-8")
    if len(data) > MAX_MESSAGE_BYTES:
        raise ValueError("outgoing message too large")
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()

def main() -> int:
    global MAX_MESSAGE_BYTES
    initialized = False
    while True:
        line = sys.stdin.buffer.readline(MAX_MESSAGE_BYTES + 1)
        if not line:
            raise EOFError("host closed before end")
        if len(line) > MAX_MESSAGE_BYTES or not line.endswith(b"\n"):
            raise ValueError("invalid message framing or size")
        message = json.loads(line.decode("utf-8"), object_pairs_hook=unique_object)
        if not isinstance(message, dict):
            raise TypeError("expected an object")
        kind = message.get("type")
        if kind == "init":
            if initialized or message.get("protocol_version") != "0.2.0":
                raise ValueError("duplicate init or unsupported protocol")
            config = message["config"]
            MAX_MESSAGE_BYTES = config["limits"]["max_message_bytes"]
            on_initialize(config, message["policy_seed"])
            initialized = True
            send({"type": "ready", "protocol_version": "0.2.0", "request_id": message["request_id"]})
        elif kind == "observe" and initialized:
            obs = message["observation"]
            actions, wake_at_ms = on_observe(obs)
            send({"type": "decision", "request_id": message["request_id"],
                  "observed_version": obs["state_version"], "actions": actions,
                  "wake_at_ms": wake_at_ms})
        elif kind == "end" and initialized:
            return 0
        else:
            raise ValueError(f"unexpected host message type: {kind!r}")

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"controller error: {error}", file=sys.stderr)
        raise SystemExit(1)
