# KitchenSched 公共控制器材料

协议版本：0.2.0。先读 RULES.md，再读取配置与消息 Schema。controller.py 是通信空模板，不是完成版程序；它会正常回应，但不进行任何生产或交付。

本包包含规则、JSON Schema、TypeScript 结构类型、Python 标准库模板与机械消息示例。examples/scenario.json 仅用于协议联调，不代表正式菜单规模、价格或评测难度。

在 Python 运行环境中用 `python controller.py` 启动，Host 经 stdin 发送 init、observe、end。stdout 只用于 JSON Lines，诊断写 stderr。提交时把代码与 submission.json 放在 ZIP 根目录。

TypeScript 文件提供结构类型，不执行运行时校验。所有字段合法性和机械约束以规则、Schema 和发布清单为准。运行时版本、允许依赖、资源预算及开发预算由测试方发布清单统一指定。
