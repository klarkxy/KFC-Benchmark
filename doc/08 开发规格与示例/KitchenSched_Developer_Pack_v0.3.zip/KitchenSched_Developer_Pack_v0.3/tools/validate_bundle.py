#!/usr/bin/env python3
"""Static contract checks; not simulator, server, or sandbox acceptance tests."""
from __future__ import annotations
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Any
try:
    import yaml
    from jsonschema import Draft202012Validator
except ImportError as exc:
    raise SystemExit("Install jsonschema and PyYAML in the test-team environment, then rerun.") from exc

ROOT = Path(__file__).resolve().parents[1]

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def walk(value: Any):
    yield value
    if isinstance(value, dict):
        for v in value.values():
            yield from walk(v)
    elif isinstance(value, list):
        for v in value:
            yield from walk(v)

def resolve_pointer(root: Any, pointer: str) -> Any:
    if not pointer.startswith("#/"):
        raise ValueError(f"Nonlocal ref not allowed in platform bundle: {pointer}")
    target = root
    for part in pointer[2:].split("/"):
        target = target[part.replace("~1", "/").replace("~0", "~")]
    return target

def check_public_config(config: dict[str, Any]) -> None:
    items = {x["id"]: x for x in config["items"]}
    stations = {x["id"] for x in config["stations"]}
    if len(items) != len(config["items"]) or len(stations) != len(config["stations"]):
        raise ValueError("duplicate config ID")
    graph = {i: set() for i in items}
    recipe_ids: set[str] = set()
    for item in items.values():
        if item["supply"] == "unlimited_raw" and item["orderable"]:
            raise ValueError("raw item cannot be orderable")
        if (item["price_minor"] > 0) != item["orderable"]:
            raise ValueError("price/orderable mismatch")
    for recipe in config["recipes"]:
        if recipe["id"] in recipe_ids:
            raise ValueError("duplicate recipe")
        recipe_ids.add(recipe["id"])
        for side in ("inputs", "outputs"):
            ids = [x["item_id"] for x in recipe[side]]
            if len(ids) != len(set(ids)) or not set(ids) <= items.keys():
                raise ValueError("invalid item references")
        for output in recipe["outputs"]:
            if items[output["item_id"]]["supply"] != "produced":
                raise ValueError("recipe cannot output unlimited raw")
        opts = [x["station_id"] for x in recipe["station_options"]]
        if len(opts) != len(set(opts)) or not set(opts) <= stations:
            raise ValueError("invalid station options")
        for source in recipe["inputs"]:
            graph[source["item_id"]].update(x["item_id"] for x in recipe["outputs"])
    active: set[str] = set()
    done: set[str] = set()
    def visit(node: str) -> None:
        if node in active:
            raise ValueError("recipe graph contains cycle")
        if node in done:
            return
        active.add(node)
        for nxt in graph[node]:
            visit(nxt)
        active.remove(node)
        done.add(node)
    for node in graph:
        visit(node)
    available = {i for i, x in items.items() if x["supply"] == "unlimited_raw"}
    changed = True
    while changed:
        changed = False
        for recipe in config["recipes"]:
            if all(x["item_id"] in available for x in recipe["inputs"]):
                before = len(available)
                available.update(x["item_id"] for x in recipe["outputs"])
                changed |= len(available) > before
    if any(x["orderable"] and i not in available for i, x in items.items()):
        raise ValueError("unreachable orderable item")
    if config["limits"]["max_actions_per_decision"] < config["limits"]["max_orders_per_run"]:
        raise ValueError("final delivery capacity too small")

def main() -> int:
    checks = []
    for path in (ROOT / "spec").glob("*.schema.json"):
        Draft202012Validator.check_schema(load_json(path))
    checks.append("JSON Schema meta-schema checks")
    schema = load_json(ROOT / "spec/controller.schema.json")
    public_schema = load_json(ROOT / "spec/public-scenario.schema.json")
    validator = Draft202012Validator(schema)
    config = load_json(ROOT / "public/examples/scenario.json")
    Draft202012Validator(public_schema).validate(config)
    check_public_config(config)
    fixture = load_json(ROOT / "examples/internal-deadline-fixture.json")
    Draft202012Validator(public_schema).validate(fixture["config"])
    check_public_config(fixture["config"])
    checks.append("Public and internal fixture configuration structures and basic semantics")
    messages = [json.loads(x) for x in (ROOT / "public/examples/messages.jsonl").read_text().splitlines()]
    for message in messages:
        validator.validate(message)
    checks.append("All public JSON Lines examples")
    Draft202012Validator(load_json(ROOT / "spec/submission.schema.json")).validate(load_json(ROOT / "public/submission.json"))
    checks.append("Submission manifest")
    api = yaml.safe_load((ROOT / "spec/platform.openapi.yaml").read_text())
    assert api["openapi"] == "3.1.1"
    operation_ids = set()
    operation_count = 0
    for node in walk(api):
        if isinstance(node, dict) and "$ref" in node:
            resolve_pointer(api, node["$ref"])
    for path, methods in api["paths"].items():
        for method, operation in methods.items():
            assert method in {"get", "post", "put", "patch", "delete", "head", "options"}
            oid = operation["operationId"]
            assert oid not in operation_ids
            operation_ids.add(oid)
            operation_count += 1
            names = {p["name"] for p in operation.get("parameters", []) if p["in"] == "path" and p.get("required")}
            assert names == set(re.findall(r"\{([^}]+)\}", path))
            assert operation["responses"]
            for security in operation.get("security", api.get("security", [])):
                assert set(security) <= set(api["components"]["securitySchemes"])
    for name, definition in api["components"]["schemas"].items():
        Draft202012Validator.check_schema(definition)
        if "example" in definition:
            Draft202012Validator({"$ref":"#/components/schemas/"+name,"components":api["components"]}).validate(definition["example"])
    checks.append(f"OpenAPI local references, component schemas, operation IDs, path parameters and examples ({operation_count} operations)")
    host_input = "".join(json.dumps(x) + "\n" for x in messages if x["type"] in {"init", "observe", "end"})
    process = subprocess.run([sys.executable, str(ROOT / "public/controller.py")], input=host_input,
                             text=True, capture_output=True, timeout=5, check=True)
    output = [json.loads(x) for x in process.stdout.splitlines()]
    assert [x["type"] for x in output] == ["ready", "decision"]
    for message in output:
        validator.validate(message)
    assert output[1]["actions"] == []
    checks.append("Python no-op template init/observe/end handshake")
    if shutil.which("tsc"):
        subprocess.run(["tsc", "--noEmit", "--strict", str(ROOT / "public/protocol.ts")], check=True, capture_output=True, timeout=20)
        checks.append("TypeScript protocol types compile with strict checks")
    assert len(load_json(ROOT / "tests/semantic_cases.json")) == 36
    result = {"status":"passed", "checks":checks, "semantic_cases_defined":36,
              "simulator_behavior_tests_executed":0,"full_openapi_conformance_validation":False,
              "production_security_audit_performed":False}
    (ROOT / "validation-report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"VALIDATION FAILED: {error}", file=sys.stderr)
        raise SystemExit(1)
