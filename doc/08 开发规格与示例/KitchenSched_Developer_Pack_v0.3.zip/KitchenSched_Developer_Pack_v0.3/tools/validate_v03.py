#!/usr/bin/env python3
"""Validate v0.3 design artifacts. Does not exercise a running platform or sandbox."""
from pathlib import Path
from hashlib import sha256
import json, subprocess, shutil
import yaml
from jsonschema import Draft202012Validator, ValidationError
R=Path(__file__).resolve().parents[1]
def read(p): return json.loads((R/p).read_text())
def main():
 api=yaml.safe_load((R/'spec/platform.openapi.yaml').read_text())
 checks=[]
 for name in ['TierScorePublic','GameCatalogEntry']:
  assert api['components']['schemas'][name]['properties']['difficulty']['enum']==api['components']['schemas']['PublicScenario']['properties']['difficulty']['enum']
 checks.append('Public result/game difficulty enums match existing easy/medium/complex contract')
 def check_instance(name,obj):
  Draft202012Validator({'$ref':'#/components/schemas/'+name,'components':api['components']}).validate(obj)
 for name,p in [('ConnectionCreate','examples/create-model-connection.json'),('ExperimentCreate','examples/create-experiment.json')]:
  x=read(p);check_instance(name,x)
  invalid=dict(x,owner_user_id='other-user')
  try:check_instance(name,invalid)
  except ValidationError:pass
  else:raise AssertionError('Owner override accepted: '+name)
 checks.append('Connection/experiment examples valid; owner override rejected by schema')
 c=api['components']['schemas']['ConnectionCreate']['properties']['api_key']
 assert c['writeOnly'] is True
 for name in ['Connection','Experiment','PublicResult','PublicShare']:
  assert 'api_key' not in api['components']['schemas'][name]['properties']
 checks.append('Credential write-only declaration and explicit response property sets')
 p=read('harness/profile.draft.json')
 assert p['release_ready'] is False and p['harness_commit'] is None
 assert p['system_prompt_sha256']==sha256((R/'prompts/system.txt').read_bytes()).hexdigest()
 assert p['task_prompt_sha256']==sha256((R/'prompts/task.txt').read_bytes()).hexdigest()
 assert p['tool_contract_sha256']==sha256((R/'harness/tools.contract.draft.json').read_bytes()).hexdigest()
 checks.append('Fixed prompt/tool draft hashes match; profile explicitly non-release')
 tools=read('harness/tools.contract.draft.json');assert [t['name'] for t in tools]==['read','write','edit','bash']
 for t in tools:Draft202012Validator.check_schema(t['parameters'])
 checks.append('Four proposed tool parameter schemas pass meta-schema validation')
 cases=read('tests/v03_acceptance.json');ids=[x['id'] for x in cases]
 assert len(ids)==35 and len(set(ids))==35 and all(x['status']=='not_executed' for x in cases)
 checks.append('35 unique v0.3 acceptance definitions explicitly marked not executed')
 if shutil.which('tsc'):
  subprocess.run(['tsc','--noEmit','--strict',str(R/'spec/browser-adapters.ts')],check=True,timeout=20)
  checks.append('Browser adapter TypeScript declarations compile')
 count=sum(len(v) for v in api['paths'].values())
 assert count==40
 checks.append('40 HTTP operation declarations; 22 added to the v0.2 contract')
 report={'status':'passed','checks':checks,'new_acceptance_definitions':35,'new_behavior_tests_executed':0,'model_or_provider_called':False,'harness_implemented':False,'sandbox_security_tested':False,'website_implemented':False,'release_ready':False}
 (R/'validation-v03-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
