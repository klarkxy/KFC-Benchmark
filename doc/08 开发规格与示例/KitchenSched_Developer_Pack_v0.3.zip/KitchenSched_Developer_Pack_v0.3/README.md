# KitchenSched Developer Pack v0.3

完整开发设计包，含 v0.2 机械规则/协议与 v0.3 三部分产品增补。先读 docs/00，再读 09、10、11。

主分为合法完整交付订单的实际交易总额。纯 PVE、简单/中等/复杂三档、约 1:4 准备/营业结构不变。

## 本轮交付
三份产品与架构文档；合并 OpenAPI 0.3.0-draft；固定系统/任务提示词草案；四工具沙箱契约草案；浏览器适配器类型；更新导航和原文范围声明；新增接口示例与验收定义。

## 尚未实现
HTML5 游戏、网站、OAuth、PiAdapter、模型网关、生成/执行沙箱和真实评测服务均未由此包实现。profile.draft.json 必须被发布运行器拒绝，不能用 null 隐式回退。

## 验证
python tools/validate_bundle.py
python tools/validate_v03.py

校验只覆盖静态规格、示例、协议模板与类型，不等于行为、安全或性能测试。validation-report.json 和 validation-v03-report.json 如实列出边界。

完整开发包包含内部计划与测试向量，不得作为参赛模型公开材料。prompts/ 只提供候选固定正文；正式公开包需白名单构建、填入开发限制并固定所有哈希。
