# KitchenSched 控制器协议与 SDK

v0.2 · protocol_version 0.2.0 · 开发者契约

## 1. 边界与传输

这是候选程序与可信 Host 之间的本地线协议，不是 HTTP 服务。正式代码赛道使用标准输入输出 JSON Lines：每条 UTF-8 JSON 消息一行，以 LF 结束，输出后必须 flush；诊断日志写 stderr。stdout 不能混入提示语、Markdown、空行或调试信息。

Host 同时最多持有一个待响应请求，候选程序不能主动发送其他消息。每个 run 启动全新进程，不允许继承前一隐藏用例的文件、缓存或内存。候选只能获得当前 run 的公开配置与已经发生的状态。

spec/controller.schema.json 是消息结构依据；spec/public-scenario.schema.json 是公开静态配置依据。Schema 只检查结构，设备互斥、物料精确匹配和时间合法性由内核负责。

## 2. 消息生命周期

Host 发送 init，候选回复 ready，版本和 request_id 必须匹配。init 包含公开 config、run_token 和独立 policy_seed；后两者不能编码订单种子。config 包括物品、配方、设备、end_at_ms、机械规则及公开 limits。

Host 随后在 t=0 和后续事件发送 observe，候选返回 decision。每个 request_id 单次使用。最后 Host 发送 end，候选无需回应，退出即可；end 之后的清理时间不再影响已结算成绩。end 之前异常退出属于候选失败。

初始化用于读配置，不能改变世界；首个 observe 才允许开工。初始化与每次决策都受真实资源预算约束，与仿真时间不同。

## 3. observe 的字段

| 字段 | 含义 |
|---|---|
| now_ms、state_version、final | 当前仿真时间、状态版本、是否仅交付的最终回调 |
| orders | 全部已到达未交付订单；不因价值低而被宿主筛除 |
| inventory | 所有正数量 produced 批次，含来源 task_id |
| running_tasks、stations | 当前加工与设备占用 |
| revenue_minor | 截至当前已记账收入，仅为事实反馈 |
| previous_results | 上一响应中各动作的结果，保持动作顺序 |
| previous_wake_result | 上次唤醒更新结果，首次为 null |
| pending_wake_at_ms | 当前已登记唤醒，未登记为 null |

静态定义只在 init 发送。动态状态优先完整快照，不发送无限历史或未来事件队列。公开观测没有 prepare 标签、开门倒计时、需求分布、价值密度、瓶颈建议或“最佳动作”。

对象数组按稳定 ID 顺序输出，previous_results 保留动作顺序。不能按收益、等待优先级或推荐生产顺序排序，这会让 Host 承担一部分策略。

## 4. decision 与动作

一个 decision 包含 type、request_id、observed_version、actions 和 wake_at_ms。actions 可以为空。action_id 为本场唯一字符串。

start：指定 recipe_id、station_id、batches、input_lots；后者只列 produced 输入，不列无限原料。deliver：指定 order_id、output_lots，恰好满足完整订单。input_lots 和 output_lots 使用 lot_id 与 quantity；重复 lot_id 被拒绝。

一个响应内按顺序执行，不整批回滚。start 不绑定订单；deliver 不自动选库存。无自动排队、取消、自动补货或最佳设备接口。

wake_at_ms 为必填：null 取消待触发唤醒；合法整数替换之；非法值仅拒绝唤醒更新，不取消先前登记，也不回滚动作。每次只保留一个未来唤醒。

## 5. 消息示例

以下只说明字段，不提供经营策略。更完整的消息与虚构配方见 public/examples。

```json
{"type":"decision","request_id":"q1","observed_version":0,"actions":[],"wake_at_ms":null}
```

```json
{"type":"start","action_id":"a1","recipe_id":"r1","station_id":"s1","batches":1,"input_lots":[]}
```

第二段是动作对象而非完整线上消息，r1 和 s1 必须来自当前 config。示例不能照抄到不匹配的场景。空模板不决定生产或交付，仅返回合法空响应。

## 6. 返回结果与幂等

ActionResult 固定字段为 action_id、ok、code、entity_id、replayed。entity_id 在成功 start 时指 Task，在成功 deliver 时指 Delivery，其余为 null。不能根据响应里的成功次数自行计算收入，权威收入只来自唯一 Delivery 账本。

首次结构合法动作的成功和失败均缓存。相同 ID 与相同动作重发只返回原结果；不同内容冲突。候选针对已经变化的状态再次尝试必须换 ID。命中缓存不会重新消费物料，也不创建事件。

业务错误：UNKNOWN_RECIPE、UNKNOWN_STATION、INCOMPATIBLE_STATION、STATION_BUSY、INVALID_BATCH、UNKNOWN_LOT、DUPLICATE_LOT、INVALID_INPUT、INSUFFICIENT_INPUT、UNKNOWN_ORDER、INCOMPLETE_ORDER、ALREADY_DELIVERED、ACTION_ID_CONFLICT、DEADLINE_REACHED。唤醒错误为 INVALID_WAKE_TIME。

错误只包含机械原因和必要对象 ID，不返回推荐替代设备、推荐批量或更高价值订单。结构与传输错误由 Host 标记 PROTOCOL_ERROR 并终止该局，不伪装成普通动作拒绝。

## 7. 预算与防无限计算

limits 对所有模型公开且按 benchmark_version 冻结。初始标定值：init_wall_ms=5,000；decision_wall_ms=2,000；total_cpu_ms=30,000；memory_mib=256；max_decisions=20,000；max_actions_per_decision=1,024；max_total_actions=200,000；min_wake_delay_ms=20；max_message_bytes=4,194,304；max_stderr_bytes=1,048,576。

这些是可运行原型的起始预算，不是正式榜定值。max_actions_per_decision 必须足以覆盖场景最大可能的终局交付数，不能无意阻止程序兑现所有已完成订单。Host 需同时限制进程数、可写磁盘、单次响应和总 CPU；合规预算与基础设施监控分别记录。

超过消息或协议预算直接终止候选，stderr 超限则截断并标记，不因纯日志过多额外改变主分，除非同时触发 CPU 等资源限制。限制字段、实际执行规则和公开说明必须一致。

## 8. SDK 的实现边界

Python SDK 负责读取一条消息、分派 init/observe/end、编码并 flush 响应；TypeScript 类型从同一 JSON Schema 生成。SDK 不包含默认调度器。正式发布时锁定候选运行时和离线依赖，所有模型使用相同发布包哈希。

本包 public/controller.py 是可运行的 no-op 通信模板，能完成握手和空响应，但不会产生收入。它不是完成版参赛解法。TypeScript 交付为协议类型基线，第二语言的完整 Host 兼容与容器镜像需按路线图实现。

模板只使用 Python 标准库。开发包的静态校验工具使用 jsonschema 与 PyYAML；这些是测试方工具，不是强制参赛依赖。安装版本应在项目 lockfile 冻结，不能把本次本地验证环境直接宣称正式比赛环境。

## 9. 提交格式

候选提交一个 ZIP，根目录包含 submission.json 与代码。submission.json 声明 protocol_version、language 和 entrypoint 字符串数组，例如 ["python", "controller.py"]。不提供 shell 字符串，不允许绝对路径、..、符号链接或写出解压目录。

公开允许依赖集合独立发布；候选不能自带运行时、下载器、隐藏模拟器或其他参赛代码。构建完成后 source_sha256、依赖锁、entrypoint 和 runtime_image_digest 一同冻结；更改任意项产生新 submission，而非覆盖历史成绩。

## 10. 扩展与兼容

本协议明确是 paused_code 时钟。未来直接 LLM 控制可以复用 Item、Order 和 Action，但必须新增时钟策略、在途请求、过时响应处理与预算定义，不自动获得与当前分数的可比性。

新增会改变合法动作或状态转移的字段需要协议版本更新。可选诊断字段也必须在 Schema 中声明；strict additionalProperties=false 下不能指望旧客户端静默接受。
