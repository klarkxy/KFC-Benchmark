# KitchenSched v0.2 开发交付包

这是设计和协议基线，不是已经完成的模拟器或评测服务。

`docs/` 是内部计划与 API 文档 Markdown 源稿；`spec/` 是控制器和平台契约；`public/` 是可交给参赛模型的材料白名单来源；`examples/` 与 `tests/` 含测试方内部语义用例；`tools/` 提供静态校验工具。不能把整个包直接发给参赛模型。

## 使用

先阅读 `docs/00_项目导航与决策记录.md`，按 `docs/06_开发路线图与测试验收.md` 推进。

在已安装 jsonschema 与 PyYAML 的测试方开发环境运行：

```sh
python tools/validate_bundle.py
```

该命令验证 JSON Schema、本地 OpenAPI 引用与基本结构、公开示例和 Python 模板握手；若发现 tsc，还会检查 TypeScript 类型。它不启动模拟器，也不宣称通过全部 OpenAPI 官方一致性测试。真实引擎行为、HTTP 实现、安全隔离与难度标定仍需开发。

`tests/semantic_cases.json` 定义 36 项行为验收，状态均为 not_implemented；`examples/internal-deadline-fixture.json` 是可人工核算的截止与幂等用例，symbolic lot ID 由未来测试适配器解析。

正式发布前统一冻结依赖、运行时镜像、公开包、场景、用例、资源、统计方法和版本哈希。`SHA256SUMS` 覆盖本包发布快照，不包含自身。
