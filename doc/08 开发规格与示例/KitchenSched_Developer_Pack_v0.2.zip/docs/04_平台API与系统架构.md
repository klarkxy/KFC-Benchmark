# KitchenSched 平台 API 与系统架构

v0.2 · HTTP 契约与模块设计 · 测试方内部

## 1. 两层接口不要混用

控制器使用 stdin/stdout 调度协议；后台使用 HTTP 管理程序、评测、成绩与回放。候选沙箱不持有 HTTP token，不可访问 Runner、榜单、对象存储或用例管理接口。浏览器和模型开发工具访问的平台接口不是厨房动作接口。

机器规格为 spec/platform.openapi.yaml，使用明确版本 OpenAPI 3.1.1；JSON Schema 使用 Draft 2020-12。服务 base URL 为相对路径 /api/v1，不虚构已部署域名。错误结构采用 RFC 9457 的 application/problem+json，并扩展 code 和 trace_id。[S1][S2][S3]

## 2. 建议工程架构

建议用 TypeScript 实现一个单一参考 Simulator、Host 协议层和 API 服务，Python 作为首个候选语言，React 作为只读 Viewer。此选型为减少首版多语言维护成本，不是已有用户决策；具体 HTTP 框架、数据库驱动与容器版本在 M0 冻结。

内核必须是纯确定性状态转移与事件队列，不依赖浏览器帧率或宿主定时器推进世界。初期单机 Worker、本地内容寻址文件和 SQLite 足够形成闭环；需要并发与多实例时替换持久层，不修改世界语义。不要首先引入分布式消息总线和自动扩缩容。

推荐模块为 spec、simulator、host、judge、runner、api、viewer、public-sdk、tests、private-cases。private-cases 作为独立受限存储，不混在候选可见工作目录。Simulator 和 Judge 的职责独立，不能复用同一错误记分函数来证明正确性。

## 3. 数据对象与版本

model_config 记录供应商、模型标识、推理设置、外层开发框架、预算与公开包哈希；这些字段构成可比较配置，不能只写品牌名。

submission 绑定一次独立生成、源文件与依赖哈希、entrypoint、运行时镜像摘要及 freeze 状态。benchmark_version 绑定规则、引擎、场景集合、隐藏用例集、预算、统计方法和发布口径。

evaluation 是一组冻结提交在一个 benchmark_version 上的完整矩阵任务。run 是其中一个候选与一个 case 的运行；attempt 是同一 run 因基础设施故障重试的物理执行。候选失败不会自动产生新 attempt。

leaderboard_snapshot 是不可变发布快照；replay_manifest 引用事件、检查点与哈希；artifact 是带归属、扫描状态、大小和 sha256 的源文件或结果对象。数据库中存元数据与索引，代码包和事件大文件存对象层。

model_config 与 benchmark 私有清单由受控、可审计的管理 CLI 预先登记；本版 HTTP 不开放隐藏用例 CRUD。上传 ZIP 的初始限制为压缩体积 10 MiB、展开 50 MiB、1,000 文件，发布前统一标定。

## 4. HTTP 端点总览

| 方法与路径 | 用途与权限 |
|---|---|
| GET /healthz | 最小存活状态，不透露版本密钥与主机信息 |
| POST /artifacts | 上传 ZIP 二进制；submitter 或 organizer，限大小并隔离扫描 |
| GET /artifacts/{artifact_id} | 查看本人或有权限的工件元数据 |
| POST /submissions | 用 ready 工件创建验证任务 |
| GET /submissions/{submission_id} | 查看状态、哈希和公开元数据 |
| POST /submissions/{submission_id}/freeze | ready 后冻结；之后不可变 |
| GET /benchmarks | 读取已发布公开版本摘要 |
| GET /benchmarks/{benchmark_id}/scenarios/{scenario_id} | 只读公开练习配置，不枚举隐藏配置 |
| POST /practice-runs | 对公开场景与公开 case 运行，不纳入主榜 |
| POST /evaluations | organizer 创建官方完整评测矩阵 |
| GET /evaluations/{evaluation_id} | 查看许可范围内进度 |
| GET /runs/{run_id} | 查看状态与可见结果，隐藏正式结果默认仅 organizer |
| GET /runs/{run_id}/events | 按 after_seq 游标读取授权事件页 |
| GET /runs/{run_id}/checkpoints | 读取指定仿真时刻之前最近的授权检查点 |
| GET /runs/{run_id}/replay-manifest | 读取已授权回放清单 |
| POST /runs/{run_id}/cancel | 取消本人练习或管理任务；官方取消必须审计与补跑 |
| GET /leaderboards/{benchmark_id} | 按难度读取已发布不可变榜单 |
| POST /leaderboards/{benchmark_id}/publish | organizer 校验矩阵并生成发布快照 |

首版回放用分页轮询，不要求 WebSocket 或 SSE。后续推送必须复用同一 seq 与快照，不另造可改变成绩的前端状态机。

## 5. 提交与冻结事务

POST /artifacts 的请求体是 application/zip 二进制，不接受任意远程 URL，避免服务器替用户抓取内部地址。上传后先 quarantine，再检查扩展名、magic、压缩后和解压后体积、文件数、路径与符号链接；扫描完成才 ready。

POST /submissions 接收 artifact_id、model_config_id、label，服务端从 submission.json 读取 entrypoint。只允许引用本租户工件和已授权模型配置。异步验证生成 validating → ready 或 rejected；freeze 仅在 ready 时生效，返回 frozen 对象。源包变更必须创建新对象。

POST /practice-runs 可使用 ready 或 frozen 提交，但保存当时不可变内容哈希。POST /evaluations 仅接受 frozen 提交，并把隐藏矩阵、引擎与预算版本在事务中快照；不能在排队期间动态指向“最新配置”。

## 6. 幂等、并发与分页

创建型 POST 和 freeze、publish 必须提供 Idempotency-Key。幂等范围为 principal＋method＋path＋key；相同规范化正文或相同上传 bytes hash 返回原对象，不重复创建任务；正文变化返回 409。服务端与资源创建在同一事务写入幂等记录，不能只用进程内缓存。建议至少保存 7 天，并在发布环境固定期限。

列表使用 limit 与 opaque cursor，稳定排序；不能用客户端传来的 SQL、文件路径或 order_by 字符串。events 的 after_seq 是排他游标，响应 next_after_seq；检查点返回 checkpoint_seq，客户端再读取 seq 大于该值的事件，不重放两次。

所有 run 状态更新采用版本或 CAS，Worker 使用 lease 与 fencing token。租约失效的旧 Worker 无权提交官方结果；数据库以 run_id＋accepted_attempt 的唯一约束保证至多一份有效账本。

## 7. 状态机与错误

run：queued → running → completed / candidate_failed / infra_failed / canceled / disqualified。completed 与 candidate_failed 可形成官方分数，前者核验收入、后者零分；infra_failed 为 null，等待同条件补跑。

客户端错误采用 400/401/403/404/409/413/415/422/429，服务端故障采用 5xx；业务错误 code 比自然语言 detail 稳定。对无权知道的隐藏资源统一 404，不从错误信息泄漏私有 case ID、seed 或路径。rate limit 应返回 Retry-After。

官方 run 被管理取消属于未完成单元，不能作为候选零分或从统计删除。需要审计原因并补跑；练习取消不计榜单。安全违规与一般程序错误区别标记。

## 8. 权限与数据投影

角色：viewer 仅读公开结果；submitter 管理自己的工件、提交和练习；organizer 运行正式评测；worker 使用更窄的单任务凭证。Bearer token 的签发依赖部署身份系统，本包不实现通用注册登录服务。

OpenAPI 的 x-roles 是本项目权限说明，不是 OpenAPI 自动执行的安全机制。后端逐对象验证 principal 归属，不能只检查“有 token”。

public projection 只保留已发布配置、成绩摘要和授权演示数据；owner projection 含自己的练习；organizer projection 才允许完整隐藏记录。正式单局原始分数也可能成为反复提交的反馈通道，应在评测开发结束前限制反馈。

发布榜单不自动发布代码、原始模型开发对话或隐藏回放。回放有独立 released 标记，必须使用演示集或已退役隐藏集。源代码可见性另由作者授权，不能与得分公开绑定。

## 9. 回放格式

EventRecord 固定 seq、at_ms、type、payload、state_version。事件类型包含 clock_advanced、task_started、task_completed、order_arrived、order_delivered、action_rejected、wake_updated、wake_fired、run_finished。每类 payload 都在平台规格中定义，不用无约束任意字典代替契约。

wake_fired 在已登记唤醒被消费时清除 pending_wake_at_ms，属于明确世界事件；不能只修改内存而遗漏回放记录。内部还保存完整 init/observe/decision 通信审计流，与公开回放分开授权。

检查点包含完整可视状态、checkpoint_seq 和 state_hash。播放器从最近检查点开始，仅应用之后事件；状态重建按同一 reducer 规则但不重新调度。系统应同时保存原始权威记录与经过授权过滤的展示版本，不能在原始记录上就地删字段。

时间轴根据真实事件解释发生了什么，不猜测程序的意图。并排播放器共享 display_time_ms，渲染暂停不向 Runner 发暂停或动作命令。

## 10. 存储约束与恢复

至少建立唯一约束：submission 内容版本、run 的 evaluation/case/submission 单元、Delivery 的 run/order、事件 run/seq、幂等 principal/method/path/key。artifact 以 bytes sha256 去重，但授权不能因为内容相同而跨租户继承。

正式完成由 Worker 提交结果包，Judge 核验后原子写 accepted_attempt、official score 和文件哈希。API 不接受客户端传来的最终 score。发布只读取已经核验的完成矩阵，生成带输入矩阵摘要的不可变 snapshot。

基础设施重跑重新启动候选进程，不能从候选程序的中间内存恢复。检查点用于回放和审计，不意味着可以恢复任意代码执行栈。

## 11. 技术参考

[S1] OpenAPI Specification 3.1.1：https://spec.openapis.org/oas/v3.1.1.html

[S2] JSON Schema Draft 2020-12：https://json-schema.org/draft/2020-12

[S3] RFC 9457，HTTP API 的 Problem Details：https://www.rfc-editor.org/rfc/rfc9457

这些资料支撑格式选择，不替本项目决定评分或世界规则。本包不声称 HTTP 服务已经部署。
